
import java.util.*;

public class Solution {

    public static void main(String[] sc) {
        Scanner scan = new Scanner(System.in);

        String n1 = scan.next();
        String n2 = scan.next();
        String n3 = scan.next();
        String p = "Hi " + n3 + ", " + n2 + ", and " + n1 + ".";

        System.out.println(p);

    }

}
