
import java.util.*;

public class Solution {

    public static void main(String[] sc) {
        Scanner scan = new Scanner(System.in);

        float a = scan.nextFloat();
        float b = scan.nextFloat();
        double c = Math.sqrt(a * a + b * b);
        System.out.println(c);
    }

}
