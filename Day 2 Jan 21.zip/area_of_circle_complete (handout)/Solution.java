import java.util.*;

public class Solution{
    public static void main(String[] sc) {
        Scanner scan = new Scanner(System.in);
        double rds = scan.nextDouble();
        double area = 3.14159 * rds * rds;
        System.out.printf("%.2f",area);
    }
}