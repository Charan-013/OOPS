# Card Class
class Card:

    def __str__(self):
        return f"{self.rank} of {self.suit}"

# Deck Class (without using random.shuffle)
class Deck:
    def __init__(self):
        # your code goes here
        self.manual_shuffle()

    def manual_shuffle(self):
        """Manually shuffle the deck without using random"""
        shuffled = []
        while len(self.cards) > 0:
            mid = len(self.cards) // 2  # Pick a middle point
            shuffled.append(self.cards.pop(mid))  # Move card to shuffled deck
        self.cards = shuffled

# Hand Class
class Hand:
    def __str__(self):
        return ', '.join(str(card) for card in self.cards)

# Player Class
class Player:
    def __str__(self):
        return f"{self.name}: {self.hand}"

# Game Class
class Game:
    pass

