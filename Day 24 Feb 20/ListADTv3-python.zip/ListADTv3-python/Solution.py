from typing import Generic, TypeVar, List, Optional, Collection

T = TypeVar('T')

class ArrayListADT(Generic[T]):
    def __init__(self, initial_capacity: int = 10) -> None:
        self._data: List[Optional[T]] = [None] * initial_capacity
        self._size: int = 0

    def size(self) -> int:
        pass

    def _resize(self, new_capacity: int) -> None:
        pass

    def ensure_capacity(self, min_capacity: int) -> None:
        pass

    def trim_to_size(self) -> None:
        pass

    def add(self, e: T) -> bool:
        pass

    def add_at(self, index: int, element: T) -> None:
        pass

    def add_all(self, collection: Collection[T]) -> bool:
        pass

    def add_all_at(self, index: int, collection: Collection[T]) -> bool:
        pass

    def get(self, index: int) -> T:
        pass

    def set(self, index: int, element: T) -> T:
        pass

    def remove_at(self, index: int) -> T:
        pass


    def remove(self, o: T) -> bool:
        pass

    def clear(self) -> None:
        pass

    def contains(self, o: T) -> bool:
        pass

    def index_of(self, o: T) -> int:
        pass

    def last_index_of(self, o: T) -> int:
        pass

    def is_empty(self) -> bool:
        pass

    def __str__(self) -> str:
        pass


