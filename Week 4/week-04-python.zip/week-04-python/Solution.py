class LuckyBingoBoard:

    def print_board(self):
        print("Board State:")
        for i in range(self.size):
            print(" ".join("X" if self.marks[i][j] else str(self.board[i][j]) for j in range(self.size)))


class Player:

    def display_board(self):
        print(f"{self.name}'s Board:")
        self.board.print_board()


class LuckyBingoGame:
    pass

