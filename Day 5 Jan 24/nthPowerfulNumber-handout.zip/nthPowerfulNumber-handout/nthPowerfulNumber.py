
def nthPowerfulNumber(n):
	return -1

print(nthPowerfulNumber(int(input())))