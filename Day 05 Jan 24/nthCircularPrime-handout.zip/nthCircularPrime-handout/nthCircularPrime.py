
def nthCircularPrime(x):
	return 0



print(nthCircularPrime(int(input())))
