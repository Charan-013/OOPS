
def nthHappyPrime(n):
	return 0



print(nthHappyPrime(int(input())))